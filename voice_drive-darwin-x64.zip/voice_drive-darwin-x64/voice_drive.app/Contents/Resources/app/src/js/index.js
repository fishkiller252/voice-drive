//音声ファイルを読み込む
// var voice = new Audio("再生する音声ファイルのURL")
var voice = new Audio("http://fishkiller.han-be.com/voice/thx.mp3");

function praise() {
  voice.play()
};
